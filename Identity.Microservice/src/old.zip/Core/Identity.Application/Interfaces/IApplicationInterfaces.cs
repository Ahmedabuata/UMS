namespace Identity.Application.Interfaces;

public interface IPasswordHasher
{
    string Hash(string password);
    bool Verify(string password, string hash);
}

public interface IJwtTokenService
{
    (string token, DateTime expiresAt) GenerateAccessToken(Guid userId, string username, string email, List<string> roles, List<string> permissions);
    string GenerateRefreshToken();
    string HashToken(string token);
}

public interface ICurrentUserService
{
    Guid? UserId { get; }
    string? Username { get; }
    string? IpAddress { get; }
    string? UserAgent { get; }
}
