namespace Identity.Domain.Entities;
public class AuditLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid? UserId { get; set; }
    public string? Action { get; set; }
    public string? Entity { get; set; }
    public string? EntityId { get; set; }
    public string? TableName { get; set; }
    public string? OldValues { get; set; } // jsonb as string - mapped in Fluent API
    public string? NewValues { get; set; } // jsonb as string - mapped in Fluent API
    public string? IpAddress { get; set; }
    public string? UserAgent { get; set; }
    public string? BranchCode { get; set; }
    public Guid? CreatedBy { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
