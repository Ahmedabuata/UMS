namespace Identity.Domain.Entities;
public class Permission
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string PermissionName { get; set; } = null!;
    public string? Description { get; set; }
    public string? Module { get; set; }
    public string? ModuleCode { get; set; }
    public string? BranchCode { get; set; }
    public bool IsSensitive { get; set; } = false;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
}
