namespace Identity.Domain.Entities;
public class UserGroup
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public Guid GroupId { get; set; }
    public DateTime JoinedAt { get; set; } = DateTime.UtcNow;
    public User User { get; set; } = null!;
    public Group Group { get; set; } = null!;
}
