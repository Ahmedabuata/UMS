using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Identity.Infrastructure.Persistence;

namespace Identity.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IdentityDbContext _db;
    private readonly IConfiguration _config;
    public AuthController(IdentityDbContext db, IConfiguration config) { _db = db; _config = config; }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Email) || string.IsNullOrWhiteSpace(req.Password))
            return BadRequest(new { message = "Email and Password required" });
        if (await _db.Users.AnyAsync(u => u.Email == req.Email))
            return BadRequest(new { message = "Email exists" });

        var roleCode = (req.Role?? "USER").ToUpper();
        var role = await _db.Roles.FirstOrDefaultAsync(r => r.RoleName == roleCode);
        if (role == null)
        {
            role = new Domain.Entities.Role { Id = Guid.NewGuid(), RoleName = roleCode, DisplayName = roleCode, IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow };
            _db.Roles.Add(role);
            await _db.SaveChangesAsync();

            string[] permCodes = roleCode == "HR_MANAGER"
               ? new[] { "HR_EMPLOYEE_READ","HR_EMPLOYEE_WRITE","HR_ATTENDANCE_READ","HR_ATTENDANCE_WRITE","HR_RECRUITMENT_READ","HR_RECRUITMENT_WRITE","HR_LEAVE_READ","HR_LEAVE_WRITE","HR_CONTRACT_READ","HR_CONTRACT_WRITE","HR_SALARY_READ","HR_SALARY_WRITE","HR_EVALUATION_READ","HR_EVALUATION_WRITE","HR_EMPLOYEE_STATUS","SUPER_ADMIN" }
                : new[] { "USER_READ","USER_WRITE","SUPER_ADMIN","BRANCH_READ","MODULE_READ","ADMIN_DEPT_READ","FACULTY_READ","BUILDING_READ","SEMESTER_READ","HR_EMPLOYEE_READ","HR_ATTENDANCE_READ","HR_RECRUITMENT_READ","HR_LEAVE_READ","HR_CONTRACT_READ","HR_SALARY_READ","HR_EVALUATION_READ" };

            foreach (var code in permCodes)
            {
                var perm = await _db.Permissions.FirstOrDefaultAsync(p => p.PermissionName == code);
                if (perm == null)
                {
                    perm = new Domain.Entities.Permission { Id = Guid.NewGuid(), PermissionName = code, IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow };
                    _db.Permissions.Add(perm);
                    await _db.SaveChangesAsync();
                }
                if (!await _db.RolePermissions.AnyAsync(rp => rp.RoleId == role.Id && rp.PermissionId == perm.Id))
                    _db.RolePermissions.Add(new Domain.Entities.RolePermission { Id = Guid.NewGuid(), RoleId = role.Id, PermissionId = perm.Id, IsActive = true, GrantedAt = DateTime.UtcNow, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow });
            }
            await _db.SaveChangesAsync();
        }

        var user = new Domain.Entities.User
        {
            Id = Guid.NewGuid(),
            Username = string.IsNullOrWhiteSpace(req.Username)? req.Email.Split('@')[0] : req.Username,
            Email = req.Email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.Password),
            IsActive = true,
            MustChangePassword = false,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        _db.UserRoles.Add(new Domain.Entities.UserRole { Id = Guid.NewGuid(), UserId = user.Id, RoleId = role.Id, AssignedAt = DateTime.UtcNow });
        await _db.SaveChangesAsync();

        // Write audit log - CREATE
        try
        {
            _db.AuditLogs.Add(new Domain.Entities.AuditLog
            {
                Id = Guid.NewGuid(),
                UserId = user.Id,
                Action = "CREATE",
                Entity = "User",
                EntityId = user.Id.ToString(),
                TableName = "users",
                NewValues = JsonSerializer.Serialize(new { user.Email, roleCode }),
                IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                UserAgent = Request.Headers["User-Agent"].ToString(),
                Timestamp = DateTime.UtcNow,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = user.Id
            });
            await _db.SaveChangesAsync();
        }
        catch { /* audit log failure should not block register */ }

        return Ok(new { user.Id, user.Email, role = role.RoleName });
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == req.Email);
        if (user == null) return Unauthorized(new { message = "Invalid credentials" });
        if (!BCrypt.Net.BCrypt.Verify(req.Password, user.PasswordHash)) return Unauthorized(new { message = "Invalid credentials" });

        var userRoles = await _db.UserRoles.Where(ur => ur.UserId == user.Id).ToListAsync();
        var roleIds = userRoles.Select(ur => ur.RoleId).ToList();
        var roles = await _db.Roles.Where(r => roleIds.Contains(r.Id)).ToListAsync();
        var rolePerms = await _db.RolePermissions.Where(rp => roleIds.Contains(rp.RoleId)).ToListAsync();
        var permIds = rolePerms.Select(rp => rp.PermissionId).ToList();
        var permissions = await _db.Permissions.Where(p => permIds.Contains(p.Id)).Select(p => p.PermissionName).ToListAsync();

        var primaryRole = roles.FirstOrDefault()?.RoleName?? "USER";
        var isSuperAdmin = roles.Any(r => r.RoleName == "SUPER_ADMIN");

        var secret = _config["Jwt:Secret"]?? "UMS_SUPER_SECRET_KEY_2024_MUST_BE_32_CHARS_MIN_1234567890";
        var issuer = _config["Jwt:Issuer"]?? "UMS.Identity";
        var audience = _config["Jwt:Audience"]?? "UMS.Frontend";
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email?? ""),
            new Claim("username", user.Username),
            new Claim("role", primaryRole),
            new Claim("isSuperAdmin", isSuperAdmin.ToString().ToLower())
        };
        claims.AddRange(permissions.Select(p => new Claim("permission", p)));
        claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r.RoleName)));

        var token = new JwtSecurityToken(issuer, audience, claims, expires: DateTime.UtcNow.AddHours(1), signingCredentials: creds);
        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

        // Write audit log - LOGIN
        try
        {
            _db.AuditLogs.Add(new Domain.Entities.AuditLog
            {
                Id = Guid.NewGuid(),
                UserId = user.Id,
                Action = "LOGIN",
                Entity = "User",
                EntityId = user.Id.ToString(),
                TableName = "users",
                IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                UserAgent = Request.Headers["User-Agent"].ToString(),
                Timestamp = DateTime.UtcNow,
                CreatedAt = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
        }
        catch { }

        return Ok(new
        {
            token = tokenString,
            user = new { id = user.Id, email = user.Email, username = user.Username, role = primaryRole, roleName = primaryRole, isSuperAdmin = isSuperAdmin, mustChangePassword = user.MustChangePassword, employeeNumber = $"ADM-{primaryRole}-202609-00001", fullName = primaryRole == "HR_MANAGER"? "Ali Sofi" : "System Admin" },
            permissions = permissions,
            roles = roles.Select(r => r.RoleName).ToList()
        });
    }

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var sub = User.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;
        if (sub == null) return Unauthorized();
        var user = await _db.Users.FindAsync(Guid.Parse(sub));
        return user == null? NotFound() : Ok(user);
    }
}

public class RegisterRequest { public string Email { get; set; } = ""; public string Username { get; set; } = ""; public string Password { get; set; } = ""; public string Role { get; set; } = "USER"; }
public class LoginRequest { public string Email { get; set; } = ""; public string Password { get; set; } = ""; }
