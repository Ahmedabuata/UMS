using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Identity.Infrastructure.Persistence;

var builder = WebApplication.CreateBuilder(args);

// Connection string - single source of truth
var cs = builder.Configuration.GetConnectionString("IdentityDb")?? "Host=localhost;Port=5432;Database=identity_db;Username=ums_user;Password=Ums_Pass_2024!";

builder.Services.AddDbContext<IdentityDbContext>(o => o.UseNpgsql(cs));
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(o => o.AddPolicy("AllowAll", p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

// JWT
var secret = builder.Configuration["Jwt:Secret"]?? "UMS_SUPER_SECRET_KEY_2024_MUST_BE_32_CHARS_MIN_1234567890";
var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
.AddJwtBearer(o => { o.TokenValidationParameters = new TokenValidationParameters { ValidateIssuerSigningKey = true, IssuerSigningKey = key, ValidateIssuer = false, ValidateAudience = false }; });

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("AllowAll");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();

