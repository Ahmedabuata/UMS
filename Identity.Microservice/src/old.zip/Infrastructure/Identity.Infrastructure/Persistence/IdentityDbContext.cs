using Identity.Application.Abstractions;
using Identity.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Identity.Infrastructure.Persistence;

public class IdentityDbContext : DbContext, IIdentityDbContext
{
    public IdentityDbContext(DbContextOptions<IdentityDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<UserGroup> UserGroups => Set<UserGroup>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    public override Task<int> SaveChangesAsync(CancellationToken ct = default) => base.SaveChangesAsync(ct);

    protected override void OnModelCreating(ModelBuilder mb)
    {
        base.OnModelCreating(mb);

        mb.Entity<User>(e => {
            e.ToTable("users"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.Username).HasColumnName("username").IsRequired();
            e.Property(x=>x.Email).HasColumnName("email");
            e.Property(x=>x.PhoneNumber).HasColumnName("phone_number");
            e.Property(x=>x.PasswordHash).HasColumnName("password_hash").IsRequired();
            e.Property(x=>x.IsActive).HasColumnName("is_active");
            e.Property(x=>x.MustChangePassword).HasColumnName("must_change_password");
            e.Property(x=>x.FailedLoginAttempts).HasColumnName("failed_login_attempts");
            e.Property(x=>x.LockoutEnd).HasColumnName("lockout_end");
            e.Property(x=>x.CreatedAt).HasColumnName("created_at");
            e.Property(x=>x.UpdatedAt).HasColumnName("updated_at");
            e.HasIndex(x=>x.Username).IsUnique();
            e.HasIndex(x=>x.Email).IsUnique().HasFilter("email IS NOT NULL");
        });

        mb.Entity<Role>(e => {
            e.ToTable("roles"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.RoleName).HasColumnName("role_name").IsRequired();
            e.Property(x=>x.DisplayName).HasColumnName("display_name");
            e.Property(x=>x.Description).HasColumnName("description");
            e.Property(x=>x.BranchCode).HasColumnName("branch_code");
            e.Property(x=>x.IsSystemRole).HasColumnName("is_system_role");
            e.Property(x=>x.IsActive).HasColumnName("is_active");
            e.Property(x=>x.CreatedAt).HasColumnName("created_at");
            e.Property(x=>x.UpdatedAt).HasColumnName("updated_at");
            e.HasIndex(x=>x.RoleName).IsUnique();
        });

        mb.Entity<Permission>(e => {
            e.ToTable("permissions"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.PermissionName).HasColumnName("permission_name").IsRequired();
            e.Property(x=>x.Description).HasColumnName("description");
            e.Property(x=>x.Module).HasColumnName("module");
            e.Property(x=>x.ModuleCode).HasColumnName("module_code");
            e.Property(x=>x.BranchCode).HasColumnName("branch_code");
            e.Property(x=>x.IsSensitive).HasColumnName("is_sensitive");
            e.Property(x=>x.IsActive).HasColumnName("is_active");
            e.Property(x=>x.CreatedAt).HasColumnName("created_at");
            e.Property(x=>x.UpdatedAt).HasColumnName("updated_at");
            e.HasIndex(x=>x.PermissionName).IsUnique();
        });

        mb.Entity<UserRole>(e => {
            e.ToTable("user_roles"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.UserId).HasColumnName("user_id");
            e.Property(x=>x.RoleId).HasColumnName("role_id");
            e.Property(x=>x.AssignedAt).HasColumnName("assigned_at");
            e.HasIndex(x=> new {x.UserId, x.RoleId}).IsUnique();
            e.HasOne(x=>x.User).WithMany(u=>u.UserRoles).HasForeignKey(x=>x.UserId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x=>x.Role).WithMany(r=>r.UserRoles).HasForeignKey(x=>x.RoleId).OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<RolePermission>(e => {
            e.ToTable("role_permissions"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.RoleId).HasColumnName("role_id");
            e.Property(x=>x.PermissionId).HasColumnName("permission_id");
            e.Property(x=>x.BranchCode).HasColumnName("branch_code");
            e.Property(x=>x.GrantedBy).HasColumnName("granted_by");
            e.Property(x=>x.GrantedAt).HasColumnName("granted_at");
            e.Property(x=>x.IsActive).HasColumnName("is_active");
            e.Property(x=>x.CreatedAt).HasColumnName("created_at");
            e.Property(x=>x.UpdatedAt).HasColumnName("updated_at");
            e.HasIndex(x=> new {x.RoleId, x.PermissionId}).IsUnique();
            e.HasOne(x=>x.Role).WithMany(r=>r.RolePermissions).HasForeignKey(x=>x.RoleId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x=>x.Permission).WithMany(p=>p.RolePermissions).HasForeignKey(x=>x.PermissionId).OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<Group>(e => {
            e.ToTable("groups"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.Name).HasColumnName("name");
            e.Property(x=>x.DisplayName).HasColumnName("display_name");
            e.Property(x=>x.Description).HasColumnName("description");
            e.Property(x=>x.BranchCode).HasColumnName("branch_code");
            e.Property(x=>x.IsActive).HasColumnName("is_active");
            e.Property(x=>x.CreatedAt).HasColumnName("created_at");
            e.Property(x=>x.UpdatedAt).HasColumnName("updated_at");
            e.HasIndex(x=>x.Name).IsUnique();
        });

        mb.Entity<UserGroup>(e => {
            e.ToTable("user_groups"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.UserId).HasColumnName("user_id");
            e.Property(x=>x.GroupId).HasColumnName("group_id");
            e.Property(x=>x.JoinedAt).HasColumnName("joined_at");
            e.HasIndex(x=> new {x.UserId, x.GroupId}).IsUnique();
            e.HasOne(x=>x.User).WithMany(u=>u.UserGroups).HasForeignKey(x=>x.UserId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x=>x.Group).WithMany(g=>g.UserGroups).HasForeignKey(x=>x.GroupId).OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<RefreshToken>(e => {
            e.ToTable("refresh_tokens"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.UserId).HasColumnName("user_id");
            e.Property(x=>x.TokenHash).HasColumnName("token_hash");
            e.Property(x=>x.IpAddress).HasColumnName("ip_address");
            e.Property(x=>x.UserAgent).HasColumnName("user_agent");
            e.Property(x=>x.ExpiresAt).HasColumnName("expires_at");
            e.Property(x=>x.Revoked).HasColumnName("revoked");
            e.Property(x=>x.ReplacedByToken).HasColumnName("replaced_by_token");
            e.Property(x=>x.CreatedAt).HasColumnName("created_at");
            e.HasOne(x=>x.User).WithMany(u=>u.RefreshTokens).HasForeignKey(x=>x.UserId).OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<AuditLog>(e => {
            e.ToTable("audit_logs"); e.HasKey(x=>x.Id);
            e.Property(x=>x.Id).HasColumnName("id");
            e.Property(x=>x.UserId).HasColumnName("user_id");
            e.Property(x=>x.Action).HasColumnName("action");
            e.Property(x=>x.Entity).HasColumnName("entity");
            e.Property(x=>x.EntityId).HasColumnName("entity_id");
            e.Property(x=>x.TableName).HasColumnName("table_name");
            e.Property(x=>x.OldValues).HasColumnName("old_values").HasColumnType("jsonb");
            e.Property(x=>x.NewValues).HasColumnName("new_values").HasColumnType("jsonb");
            e.Property(x=>x.IpAddress).HasColumnName("ip_address");
            e.Property(x=>x.UserAgent).HasColumnName("user_agent");
            e.Property(x=>x.BranchCode).HasColumnName("branch_code");
            e.Property(x=>x.CreatedBy).HasColumnName("created_by");
            e.Property(x=>x.Timestamp).HasColumnName("timestamp");
            e.Property(x=>x.CreatedAt).HasColumnName("created_at");
        });
    }
}
