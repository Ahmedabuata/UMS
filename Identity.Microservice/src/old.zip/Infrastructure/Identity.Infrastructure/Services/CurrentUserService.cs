using Identity.Application.Interfaces;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
namespace Identity.Infrastructure.Services;
public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _accessor;
    public CurrentUserService(IHttpContextAccessor accessor) => _accessor = accessor;
    public Guid? UserId
    {
        get
        {
            var id = _accessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier) ?? _accessor.HttpContext?.User?.FindFirstValue("sub");
            return Guid.TryParse(id, out var g) ? g : null;
        }
    }
    public string? Username => _accessor.HttpContext?.User?.FindFirstValue(ClaimTypes.Name);
    public string? IpAddress => _accessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();
    public string? UserAgent => _accessor.HttpContext?.Request?.Headers.UserAgent.ToString();
}
